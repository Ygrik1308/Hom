/*
 * ARM3_PLUS.cpp
 *
 *  Created on: 1 ����. 2020 �.
 *      Author: HP
 */

#include "main.h"

struct Triangled
{
    double length = 2.0;
    double width = 2.0;
};



